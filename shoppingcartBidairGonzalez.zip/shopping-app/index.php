<?php

include 'header.php';
require_once 'config.php';


?>

    <div id="home">
      <div class="jumbotron" style="margin-bottom: 0">
        <div class="text-center">
          <h1>Welcome to Belizean Amazon</h1>
        </div>
        <div class="row">
          <div class="text-center offset-1 col-10">
            <p>
              We sell the best belizean products from chet.
            </p>
          </div>
        </div>
      </div>

      <div id="items" class="container text-center" style="margin-top: 30px">
        <form id="search">
          <div class="row">
            <div class="col-md-9">
              <div class="row">
                <div class="col-9">
                  <div class="form-group">
                    <input
                      class="form-control"
                      type="text"
                      name="search"
                      placeholder="Search"
                    />
                  </div>
                </div>
                <div class="col-3">
                  <button class="btn btn-outline-info" type="submit">Submit</button>
                </div>
              </div>
            </div>
          </div>
        </form>
        <div class="row">
          <?php
            $sql = "SELECT item_id, title, description, price, picture_url FROM items;";

            if($result = $mysqli->query($sql)){
              while($row = $result->fetch_object()){
                echo "
                <div class='col-md-6 col-12 text-center' style='padding-bottom: 50px'>
                <div class='card' style='width: 75%'>
                <img src='$row->picture_url' class='card-img-top' alt='...' />
                <div class='card-body'>
                <h5 class='card-title'>$row->title</h5>
                <p class='card-text'>$row->description</p>
                <span>
                  $$row->price
                  <button class='btn btn-outline-info add_to_cart' data-id='$row->item_id' >Add to Cart</button>
                </span>
                </div>
                </div>
                </div>
                ";
              }
            } else {
              echo nl2br("\nERROR: Failed to execute $sql. " . mysqli_error($mysqli));
          }
              
          ?>
        </div>
      </div>
    </div>


<?php

include 'footer.php';

?>